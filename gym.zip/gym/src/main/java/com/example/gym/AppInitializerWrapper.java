package com.example.gym;

public class AppInitializerWrapper {
    public static void main(String[] args) {
        AppInitializer.main(args);
    }
}
