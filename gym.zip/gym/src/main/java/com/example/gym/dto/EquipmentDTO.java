package com.example.gym.dto;

import lombok.*;
@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor

public class EquipmentDTO {
    private String Equipmentid;
    private String Equipmentname;
    private String Equipmenttype;
    private String PurchaseDate;
}
