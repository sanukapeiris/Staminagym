package com.example.gym.dto;

import lombok.*;
@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor

public class FeedbackDTO {
    private String Feedback ;
    private String Date;
}
