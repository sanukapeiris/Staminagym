package com.example.gym.model;
import com.example.gym.db.DbConnection;
import com.example.gym.dto.EquipmentDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EquipmentModel {
    public boolean saveEquipment(EquipmentDTO dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "INSERT INTO customer VALUES(?, ?, ?, ?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getEquipmentid());
        pstm.setString(2, dto.getEquipmentname());
        pstm.setString(3, dto.getEquipmenttype());
        pstm.setString(4, dto.getPurchaseDate());

        boolean isSaved = pstm.executeUpdate() > 0;

        return isSaved;
    }
}
