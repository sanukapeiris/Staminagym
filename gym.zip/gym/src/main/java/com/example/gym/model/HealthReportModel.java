package com.example.gym.model;

import com.example.gym.db.DbConnection;
import com.example.gym.dto.FeedbackDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class HealthReportModel {
    public boolean saveFeedback(FeedbackDTO dto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "INSERT INTO customer VALUES(?, ?)";
        PreparedStatement pstm = connection.prepareStatement(sql);

        pstm.setString(1, dto.getFeedback());
        pstm.setString(2, dto.getDate());

        boolean isSaved = pstm.executeUpdate() > 0;

        return isSaved;
    }
}
