package com.example.gym.dto;

import java.util.List;
import com.example.gym.dto.tm.CartTM;
import lombok.*;

import java.util.ArrayList;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor

public class SuplimentsDTO {
    private String ProductName;
    private String ProductQTY;


}

