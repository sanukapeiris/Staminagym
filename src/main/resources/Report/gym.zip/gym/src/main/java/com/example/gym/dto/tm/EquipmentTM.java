package com.example.gym.dto.tm;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor

public class EquipmentTM {
    private String Equipmentid;
    private String Equipmentname;
    private String Equipmenttype;
    private String PurchaseDate;
}
