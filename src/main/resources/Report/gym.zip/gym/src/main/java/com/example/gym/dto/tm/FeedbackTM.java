package com.example.gym.dto.tm;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class FeedbackTM {
    private String FeedbackText ;
    private String FeedbackDate;
}
