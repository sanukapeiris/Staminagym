package com.example.gym.dto.tm;

import lombok.*;
@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor


public class InventoryTM {

        private String ProductName;
        private String ProductQTY;
        private String ProductPrice;
}
