package com.example.gym.dto.tm;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class MemberTM {
    private String MemberID;
    private String FistName;
    private String LastName;
    private String Age;
    private String Gender;
    private String Birth ;
    private String Email;
    private String ContactNo;
}
