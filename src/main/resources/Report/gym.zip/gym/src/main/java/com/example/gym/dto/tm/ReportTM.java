package com.example.gym.dto.tm;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class ReportTM {
    private String FromDate;
    private String ToDate;
    private String Income;
}
