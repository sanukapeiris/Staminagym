package com.example.gym.dto.tm;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor

public class SuplimentsTM {

        private String ProductName;
        private String ProductQTY;
}
